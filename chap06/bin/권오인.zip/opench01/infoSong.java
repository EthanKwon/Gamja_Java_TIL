package opench01;

public class infoSong {
	public static void main(String[] args) {
		Song song = new Song("Love of My Life", "Queen", 
				"A Night at the Opera", "Freddie Mercury", 1975, 9);
		song.showSong();
	}
}
